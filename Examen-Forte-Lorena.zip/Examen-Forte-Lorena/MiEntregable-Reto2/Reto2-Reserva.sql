CREATE OR REPLACE TRIGGER TRG_REGISTRAR_FECHAS_FIN 
BEFORE INSERT ON RESERVA
FOR EACH ROW
DECLARE
    v_ultima_fecha RESERVA.fecha_fin%TYPE;
BEGIN
    -- Obtener la última fecha de fin de cualquier reserva
    SELECT MAX(fecha_fin)
    INTO v_ultima_fecha
    FROM RESERVA;
    -- Verificar si la nueva fecha de inicio es posterior a la última fecha de fin
    IF :NEW.fecha_inicio <= v_ultima_fecha THEN
        RAISE_APPLICATION_ERROR(-20001, 'No se puede Registrar esta fecha ya esta asignada.');
    END IF;
END;