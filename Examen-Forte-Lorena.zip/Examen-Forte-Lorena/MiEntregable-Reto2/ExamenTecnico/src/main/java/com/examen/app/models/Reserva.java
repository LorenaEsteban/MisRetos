package com.examen.app.models;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Reserva {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)//Especifica que el valor del campo id se generará automáticamente.
	private Long id;
	
	 	@Column(nullable = false) //indica que los campos, no pueden ser nulos
	 	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss") //aqui le damos el formato para la fechaInicio 
	    private LocalDateTime fechaInicio;

	    @Column(nullable = false)
	    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss") //aqui le damos el formato para la fechaFin 
	    private LocalDateTime fechaFin;

	    @Column(nullable = false)
	    private Long idHabitacion;

	    @Column(nullable = false)
	    private String nombreCliente;

	    @Column(nullable = false)
	    private String estadoReserva;
	    
	    // Constructor sin argumentos (necesario para JPA)
	    public Reserva() {
	    	
	    }
	 // Constructor con todos los argumentos
	    public Reserva(LocalDateTime fechaInicio, LocalDateTime fechaFin, Long idHabitacion, String nombreCliente, String estadoReserva) {
	        this.fechaInicio = fechaInicio;
	        this.fechaFin = fechaFin;
	        this.idHabitacion = idHabitacion;
	        this.nombreCliente = nombreCliente;
	        this.estadoReserva = estadoReserva;
	    }

	    //generar losa Get y Set
	    
		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public LocalDateTime getFechaInicio() {
			return fechaInicio;
		}

		public void setFechaInicio(LocalDateTime fechaInicio) {
			this.fechaInicio = fechaInicio;
		}

		public LocalDateTime getFechaFin() {
			return fechaFin;
		}

		public void setFechaFin(LocalDateTime fechaFin) {
			this.fechaFin = fechaFin;
		}

		public Long getIdHabitacion() {
			return idHabitacion;
		}

		public void setIdHabitacion(Long idHabitacion) {
			this.idHabitacion = idHabitacion;
		}

		public String getNombreCliente() {
			return nombreCliente;
		}

		public void setNombreCliente(String nombreCliente) {
			this.nombreCliente = nombreCliente;
		}

		public String getEstadoReserva() {
			return estadoReserva;
		}

		public void setEstadoReserva(String estadoReserva) {
			this.estadoReserva = estadoReserva;
		}
	    
	    
	    
}
