package com.examen.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenTecnicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenTecnicoApplication.class, args);
	}

}
