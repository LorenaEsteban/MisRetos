package com.examen.app.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.examen.app.models.Reserva;
import com.examen.app.repository.ReservaRepo;



@RestController
public class ReservaControllers {
	@Autowired
	ReservaRepo repoReservaRepo;
	
	public ReservaControllers (ReservaRepo repoReservaRepo) {
		this.repoReservaRepo = repoReservaRepo;
		
	}
	
	//leer datos 
	@GetMapping("/api/reserva")
	public List<Reserva>lista(){
		return repoReservaRepo.findAll();
	}
	
	@GetMapping("/api/reserva/{id}")
	public ResponseEntity<Reserva> obtener(@PathVariable Long id) {
		Optional<Reserva> opt = repoReservaRepo.findById(id);
		
		if (opt.isEmpty()) {
			return ResponseEntity.badRequest().build();
		}
		else {
			return ResponseEntity.ok(opt.get());
		}
	}
	
	//crear los datos 
	@PostMapping("/api/reserva")
	public ResponseEntity<Reserva> guardar(@RequestBody Reserva reserva) {
		
		if (reserva.getId()!=null) {
			return ResponseEntity.badRequest().build();
		}		
		repoReservaRepo.save(reserva);
		return ResponseEntity.ok(reserva);
	}
	
	//artualizar los datos 
	@PutMapping("/api/reserva")
	public ResponseEntity<Reserva> actualizar(@RequestBody Reserva reserva) {		
		if (reserva.getId()==null || !repoReservaRepo.existsById(reserva.getId()))
		{
			return ResponseEntity.badRequest().build();
		}		
		repoReservaRepo.save(reserva);
		return ResponseEntity.ok(reserva);
	}
	
	//eliminar los datos 
	@DeleteMapping("/api/reserva/{id}")
	public ResponseEntity<Reserva> borrar(@PathVariable Long id) {		
		if (id == null || !repoReservaRepo.existsById(id))
		{
			return ResponseEntity.badRequest().build();
		}		
		repoReservaRepo.deleteById(id);
		return ResponseEntity.noContent().build();
	}
	
}


