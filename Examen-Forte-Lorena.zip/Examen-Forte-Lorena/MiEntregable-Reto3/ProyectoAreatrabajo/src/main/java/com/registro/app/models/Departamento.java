package com.registro.app.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Departamento {

    @Id
    private int numero;
    private String departamento;
    private String nombreCorto;
    private String direccion;

    //se genera un contructor vacio 
    public Departamento() {
    }
    
    //se crea el contructor 
    public Departamento(int numero, String departamento, String nombreCorto, String direccion) {
		super();
		this.numero = numero;
		this.departamento = departamento;
		this.nombreCorto = nombreCorto;
		this.direccion = direccion;
	}

    //generar el get y set 
    
	public int getNumero() {
		return numero;
	}


	public void setNumero(int numero) {
		this.numero = numero;
	}


	public String getDepartamento() {
		return departamento;
	}


	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}


	public String getNombreCorto() {
		return nombreCorto;
	}


	public void setNombreCorto(String nombreCorto) {
		this.nombreCorto = nombreCorto;
	}


	public String getDireccion() {
		return direccion;
	}


	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
    
    
   
}
