package com.registro.app.models;

import java.time.LocalDate;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Empleado_")
public class Empleado {
	 @Id
	  
	 	private int numeroEmpleado;
	    private String nombre;
	    private String apellidos;
	    private int edad;
	    private LocalDate fechaIngreso;
	    
	    @ManyToOne
	    private Departamento areaTrabajo;
	    
	    public Empleado () {
	    	
	    }
	    //generar un contructor 
	    public Empleado(int numeroEmpleado, String nombre, String apellidos, int edad, LocalDate fechaIngreso,
				Departamento areaTrabajo) {
			super();
			this.numeroEmpleado = numeroEmpleado;
			this.nombre = nombre;
			this.apellidos = apellidos;
			this.edad = edad;
			this.fechaIngreso = fechaIngreso;
			this.areaTrabajo = areaTrabajo;
		}


		public int getNumeroEmpleado() {
			return numeroEmpleado;
		}

		public void setNumeroEmpleado(int numeroEmpleado) {
			this.numeroEmpleado = numeroEmpleado;
		}

		public String getNombre() {
			return nombre;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public String getApellidos() {
			return apellidos;
		}

		public void setApellidos(String apellidos) {
			this.apellidos = apellidos;
		}

		public int getEdad() {
			return edad;
		}

		public void setEdad(int edad) {
			this.edad = edad;
		}

		public LocalDate getFechaIngreso() {
			return fechaIngreso;
		}

		public void setFechaIngreso(LocalDate fechaIngreso) {
			this.fechaIngreso = fechaIngreso;
		}

		public Departamento getAreaTrabajo() {
			return areaTrabajo;
		}

		public void setAreaTrabajo(Departamento areaTrabajo) {
			this.areaTrabajo = areaTrabajo;
		}
	    
	    
}
