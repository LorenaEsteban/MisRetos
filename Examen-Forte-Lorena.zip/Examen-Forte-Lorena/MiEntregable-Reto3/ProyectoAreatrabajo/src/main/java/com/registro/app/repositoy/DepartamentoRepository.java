package com.registro.app.repositoy;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.registro.app.models.Departamento;

@Repository
public interface DepartamentoRepository extends JpaRepository<Departamento, Integer>{

	//Departamento findByNombreCorto(String nombreCorto);
	 Optional<Departamento> findByNombreCorto(String nombreCorto);
}
