package com.registro.app.controllers;

public class OperacionRequest {

	
	private String operacion;
    private String registro;
    private String datos;
    
    
    // crear el Constructor
    
	public OperacionRequest(String operacion, String registro, String datos) {
		super();
		this.operacion = operacion;
		this.registro = registro;
		this.datos = datos;
	}

	//getters y setters
	public String getOperacion() {
		return operacion;
	}


	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}


	public String getRegistro() {
		return registro;
	}


	public void setRegistro(String registro) {
		this.registro = registro;
	}


	public String getDatos() {
		return datos;
	}


	public void setDatos(String datos) {
		this.datos = datos;
	}
	
	
}
