package com.registro.app.controllers;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.registro.app.models.Departamento;
import com.registro.app.models.Empleado;
import com.registro.app.repositoy.DepartamentoRepository;
import com.registro.app.repositoy.EmpleadoRepository;

@RestController
@RequestMapping ("/practica")
public class MiOperacionControllers {

	// se manda a llamar los dos repositorio  "DEPARTAMENTO" y "EMPLEADO"
	@Autowired
	private DepartamentoRepository departamentoRepository;
	@Autowired
	private EmpleadoRepository empleadoRepository;
	
	 @PostMapping("/operacion")
	    public ResponseEntity<?> realizarOperacion(@RequestBody OperacionRequest request) {
	        try {
	        	if (request.getRegistro() == null) {
	                return ResponseEntity.badRequest().body("El campo 'registro' no puede ser nulo");
	            }
	        	
	            if (request.getRegistro().equalsIgnoreCase("areaTrabajo")) {
	                return procesarDepartamento(request);
	            } else if (request.getRegistro().equalsIgnoreCase("EMPLEADO")) {
	                return procesarEmpleado(request);
	            } else {
	                return ResponseEntity.badRequest().body("Registro no válido");
	            }
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al procesar la solicitud: " + e.getMessage());
	        }
	    }

	 
	 //-------------------------
	 private ResponseEntity<?> procesarDepartamento(OperacionRequest request) {
		 String[] datos = request.getDatos().split("-");
	        if (datos.length < 4) {
	            return ResponseEntity.badRequest().body("Formato de datos incorrecto para Departamento");
	        }
	        int numero;
	        try {
	            numero = Integer.parseInt(datos[0]);
	        } catch (NumberFormatException e) {
	            return ResponseEntity.badRequest().body("Número de departamento inválido");
	        }
	        String departamento = datos[1];
	        String nombreCorto = datos[2];
	        String direccion = datos[3];
	        
	        switch (request.getOperacion().toUpperCase()) {
	            case "ALTA":
	                Departamento nuevoDepartamento = new Departamento(numero, departamento, nombreCorto, direccion);
	                return ResponseEntity.ok(departamentoRepository.save(nuevoDepartamento));
	            case "MODIFICACION":
	                Optional<Departamento> departamentoOptional = departamentoRepository.findById(numero);
	                if (departamentoOptional.isPresent()) {
	                    Departamento departamentoExistente = departamentoOptional.get();
	                    departamentoExistente.setDepartamento(departamento);
	                    departamentoExistente.setNombreCorto(nombreCorto);
	                    departamentoExistente.setDireccion(direccion);
	                    return ResponseEntity.ok(departamentoRepository.save(departamentoExistente));
	                } else {
	                    return ResponseEntity.notFound().build();
	                }
	            case "CONSULTA":
	                // Implementar lógica de consulta por nombreCorto
	                return ResponseEntity.ok(departamentoRepository.findByNombreCorto(nombreCorto));
	            default:
	                return ResponseEntity.badRequest().body("Operación no válida");
	        }
		 
		
	    }
	 //-----------------------------
	 	private ResponseEntity<?> procesarEmpleado(OperacionRequest request) {
	        
	 		String[] datos = request.getDatos().split(" ");
			return null;
	    }

	    private int calcularEdad(LocalDate fechaNacimiento) {
	        LocalDate ahora = LocalDate.now();
	        return ahora.getYear() - fechaNacimiento.getYear();
	    }
	    
	    
	    
	}
	 

